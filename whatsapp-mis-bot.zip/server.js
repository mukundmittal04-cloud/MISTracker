// ═══════════════════════════════════════════════════════════════
// WHATSAPP MIS BOT — Complete Server
// Reads group messages, parses financial data, stores to Google Sheet
// 
// SETUP: See bottom of file for step-by-step instructions
// ═══════════════════════════════════════════════════════════════

const express = require('express');
const { google } = require('googleapis');
const app = express();
app.use(express.json());

// ── CONFIG (fill these in) ──
const CONFIG = {
  // From Meta Developer Dashboard
  WHATSAPP_VERIFY_TOKEN: 'your_verify_token_here',  // You create this — any random string
  WHATSAPP_API_TOKEN: 'your_api_token_here',         // From Meta dashboard
  WHATSAPP_PHONE_ID: 'your_phone_number_id',         // From Meta dashboard
  
  // Google Sheets (for storing parsed MIS)
  GOOGLE_SHEET_ID: 'your_google_sheet_id_here',      // From sheet URL
  GOOGLE_CREDENTIALS_PATH: './credentials.json',      // Service account key file
  
  PORT: process.env.PORT || 3000,
};


// ═══ MIS PARSER ENGINE ═══
// Detects and categorizes financial messages from your group

function parseMISMessage(message, sender, timestamp) {
  const text = message.toLowerCase();
  const result = {
    raw: message,
    sender: sender,
    timestamp: timestamp,
    date: new Date(timestamp * 1000).toISOString().split('T')[0],
    type: 'general',
    category: 'uncategorized',
    amounts: [],
    signals: [],
    parsed: {},
  };

  // ── Extract all amounts ──
  // Pattern: ₹XX,XXX or ₹XX.XX Cr or ₹XX.XX L or just numbers with context
  const crPattern = /₹?\s*(\d+(?:\.\d+)?)\s*(?:cr|crore|crores)/gi;
  const lPattern = /₹?\s*(\d+(?:\.\d+)?)\s*(?:l|lakh|lakhs|lac)/gi;
  const rupeePattern = /₹\s*(\d{1,3}(?:,\d{2,3})*(?:\.\d+)?)/g;
  
  let match;
  while ((match = crPattern.exec(message)) !== null) {
    result.amounts.push({ value: parseFloat(match[1]), unit: 'Cr', raw: match[0] });
  }
  while ((match = lPattern.exec(message)) !== null) {
    result.amounts.push({ value: parseFloat(match[1]), unit: 'L', raw: match[0] });
  }
  while ((match = rupeePattern.exec(message)) !== null) {
    const num = parseFloat(match[1].replace(/,/g, ''));
    if (!result.amounts.some(a => message.indexOf(a.raw) === message.indexOf(match[0]))) {
      result.amounts.push({ value: num, unit: '₹', raw: match[0] });
    }
  }

  // ── Categorize message type ──
  
  // Daily MIS
  if (text.includes('daily mis') || text.includes('collection') && text.includes('expenditure') || 
      text.includes('closing balance') || text.includes('opening balance')) {
    result.type = 'daily_mis';
    result.category = 'daily_sheet';
    
    // Try to extract collection and expenditure
    const collMatch = message.match(/collection[:\s]*₹?\s*([\d,]+)/i);
    const expMatch = message.match(/expenditure[:\s]*₹?\s*([\d,]+)/i);
    const closingMatch = message.match(/closing\s*(?:balance)?[:\s]*₹?\s*([\d,.]+)/i);
    
    if (collMatch) result.parsed.collection = parseFloat(collMatch[1].replace(/,/g, ''));
    if (expMatch) result.parsed.expenditure = parseFloat(expMatch[1].replace(/,/g, ''));
    if (closingMatch) result.parsed.closingBalance = parseFloat(closingMatch[1].replace(/,/g, ''));
  }
  
  // Fund Position
  else if (text.includes('fund position') || text.includes('net usable') || text.includes('bank balance')) {
    result.type = 'fund_position';
    result.category = 'fund_position';
    
    const usableMatch = message.match(/(?:net\s*usable|useable)[:\s]*₹?\s*([\d,.]+\s*(?:l|lakh|cr)?)/i);
    if (usableMatch) result.parsed.netUsable = usableMatch[1];
  }
  
  // Site update
  else if (text.includes('contractor') || text.includes('outstanding') || text.includes('steel') || 
           text.includes('rmc') || text.includes('site')) {
    result.type = 'site_update';
    result.category = 'construction';
  }
  
  // Sales / Booking
  else if (text.includes('booking') || text.includes('unsold') || text.includes('inventory') || 
           text.includes('sold') || text.includes('unit')) {
    result.type = 'sales_update';
    result.category = 'sales';
  }
  
  // Promoter draws
  else if (text.includes('mm ') || text.includes('sm ') || text.includes('drawing') || 
           text.includes('promoter') || text.includes('directors')) {
    result.type = 'promoter_draw';
    result.category = 'promoter';
    
    const mmMatch = message.match(/mm[:\s]*₹?\s*([\d,.]+\s*(?:l|lakh|cr)?)/i);
    const smMatch = message.match(/sm[:\s]*₹?\s*([\d,.]+\s*(?:l|lakh|cr)?)/i);
    if (mmMatch) result.parsed.mmDraw = mmMatch[1];
    if (smMatch) result.parsed.smDraw = smMatch[1];
  }
  
  // Office expense
  else if (text.includes('office') || text.includes('gk-1') || text.includes('gk1') || 
           text.includes('salary') || text.includes('electricity')) {
    result.type = 'office_expense';
    result.category = 'office';
  }
  
  // Legal / Compliance
  else if (text.includes('rera') || text.includes('oc ') || text.includes('compliance') || 
           text.includes('legal') || text.includes('edc') || text.includes('noc')) {
    result.type = 'compliance';
    result.category = 'legal';
  }

  // ── Extract risk signals ──
  const riskKeywords = ['pressing', 'delay', 'shortage', 'risk', 'overrun', 'stuck', 'urgent', 
                         'critical', 'crunch', 'deficit', 'negative', 'cancel', 'refund'];
  const costKeywords = ['price up', 'price increase', 'hike', 'escalation', 'costlier'];
  
  riskKeywords.forEach(kw => {
    if (text.includes(kw)) result.signals.push({ type: 'risk', keyword: kw });
  });
  costKeywords.forEach(kw => {
    if (text.includes(kw)) result.signals.push({ type: 'cost_escalation', keyword: kw });
  });

  return result;
}


// ═══ GOOGLE SHEETS INTEGRATION ═══

let sheets;
async function initSheets() {
  try {
    const auth = new google.auth.GoogleAuth({
      keyFile: CONFIG.GOOGLE_CREDENTIALS_PATH,
      scopes: ['https://www.googleapis.com/auth/spreadsheets'],
    });
    sheets = google.sheets({ version: 'v4', auth });
    console.log('Google Sheets connected');
  } catch (err) {
    console.log('Google Sheets not configured — storing locally only');
  }
}

async function appendToSheet(parsedMessage) {
  if (!sheets) return;
  
  try {
    await sheets.spreadsheets.values.append({
      spreadsheetId: CONFIG.GOOGLE_SHEET_ID,
      range: 'MIS_Feed!A:J',
      valueInputOption: 'USER_ENTERED',
      requestBody: {
        values: [[
          parsedMessage.date,
          parsedMessage.sender,
          parsedMessage.type,
          parsedMessage.category,
          parsedMessage.raw,
          parsedMessage.amounts.map(a => `${a.raw}`).join(', '),
          parsedMessage.signals.map(s => s.type).join(', '),
          JSON.stringify(parsedMessage.parsed),
          new Date().toISOString(),
          parsedMessage.signals.length > 0 ? 'YES' : '',
        ]],
      },
    });
  } catch (err) {
    console.error('Sheet write error:', err.message);
  }
}


// ═══ LOCAL STORAGE (backup) ═══

const messages = []; // In-memory store — replace with database for production

function storeLocally(parsedMessage) {
  messages.push(parsedMessage);
  // Keep last 1000 messages in memory
  if (messages.length > 1000) messages.shift();
}


// ═══ WHATSAPP WEBHOOK ENDPOINTS ═══

// Webhook verification (Meta sends a GET request to verify your endpoint)
app.get('/webhook', (req, res) => {
  const mode = req.query['hub.mode'];
  const token = req.query['hub.verify_token'];
  const challenge = req.query['hub.challenge'];

  if (mode === 'subscribe' && token === CONFIG.WHATSAPP_VERIFY_TOKEN) {
    console.log('Webhook verified');
    res.status(200).send(challenge);
  } else {
    res.sendStatus(403);
  }
});

// Receive messages (Meta POSTs every message here)
app.post('/webhook', async (req, res) => {
  try {
    const body = req.body;
    
    if (body.object === 'whatsapp_business_account') {
      for (const entry of body.entry || []) {
        for (const change of entry.changes || []) {
          if (change.field === 'messages') {
            const value = change.value;
            
            for (const message of value.messages || []) {
              // Only process text messages
              if (message.type === 'text') {
                const senderPhone = message.from;
                const text = message.text.body;
                const timestamp = message.timestamp;
                
                // Get sender name from contacts
                const contact = (value.contacts || []).find(c => c.wa_id === senderPhone);
                const senderName = contact?.profile?.name || senderPhone;
                
                console.log(`\n📩 Message from ${senderName}:`);
                console.log(`   ${text.substring(0, 100)}...`);
                
                // Parse the MIS message
                const parsed = parseMISMessage(text, senderName, parseInt(timestamp));
                
                console.log(`   Type: ${parsed.type} | Category: ${parsed.category}`);
                console.log(`   Amounts: ${parsed.amounts.length} found`);
                console.log(`   Signals: ${parsed.signals.map(s => s.type).join(', ') || 'none'}`);
                
                // Store
                storeLocally(parsed);
                await appendToSheet(parsed);
                
                // If critical signal detected, log prominently
                if (parsed.signals.some(s => s.type === 'risk')) {
                  console.log(`   ⚠️ RISK SIGNAL DETECTED: ${parsed.signals.map(s => s.keyword).join(', ')}`);
                }
              }
              
              // Handle image messages (MIS screenshots)
              if (message.type === 'image') {
                const senderPhone = message.from;
                const contact = (value.contacts || []).find(c => c.wa_id === senderPhone);
                const senderName = contact?.profile?.name || senderPhone;
                const caption = message.image?.caption || '';
                
                console.log(`\n📸 Image from ${senderName}: ${caption}`);
                
                // Store image reference — you can download and OCR later
                storeLocally({
                  raw: `[Image] ${caption}`,
                  sender: senderName,
                  timestamp: parseInt(message.timestamp),
                  date: new Date(parseInt(message.timestamp) * 1000).toISOString().split('T')[0],
                  type: 'image_mis',
                  category: 'image',
                  amounts: [],
                  signals: [],
                  parsed: { imageId: message.image?.id, caption },
                });
              }
            }
          }
        }
      }
    }
    
    res.sendStatus(200);
  } catch (err) {
    console.error('Webhook error:', err);
    res.sendStatus(200); // Always return 200 to Meta
  }
});


// ═══ API ENDPOINTS (for your tracker to read) ═══

// Get all parsed messages
app.get('/api/messages', (req, res) => {
  const limit = parseInt(req.query.limit) || 50;
  const type = req.query.type; // filter by type
  
  let filtered = messages;
  if (type) filtered = messages.filter(m => m.type === type);
  
  res.json({
    count: filtered.length,
    messages: filtered.slice(-limit).reverse(),
  });
});

// Get signals/alerts only
app.get('/api/signals', (req, res) => {
  const withSignals = messages.filter(m => m.signals.length > 0);
  res.json({
    count: withSignals.length,
    signals: withSignals.slice(-20).reverse(),
  });
});

// Get daily summary
app.get('/api/daily-summary', (req, res) => {
  const date = req.query.date || new Date().toISOString().split('T')[0];
  const dayMessages = messages.filter(m => m.date === date);
  
  const dailyMIS = dayMessages.find(m => m.type === 'daily_mis');
  const signals = dayMessages.filter(m => m.signals.length > 0);
  
  res.json({
    date,
    messageCount: dayMessages.length,
    dailyMIS: dailyMIS?.parsed || null,
    signals: signals.map(s => ({ sender: s.sender, signals: s.signals, text: s.raw.substring(0, 200) })),
    categories: dayMessages.reduce((acc, m) => { acc[m.category] = (acc[m.category] || 0) + 1; return acc; }, {}),
  });
});

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'ok', messages: messages.length, uptime: process.uptime() });
});


// ═══ START ═══
app.listen(CONFIG.PORT, async () => {
  await initSheets();
  console.log(`\n🟢 WhatsApp MIS Bot running on port ${CONFIG.PORT}`);
  console.log(`   Webhook URL: https://your-domain.com/webhook`);
  console.log(`   API: /api/messages, /api/signals, /api/daily-summary`);
});
