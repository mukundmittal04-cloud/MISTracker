# WhatsApp MIS Bot — Setup Guide
## For Fidato Group Real Estate Tracker

---

## What This Does

You add a WhatsApp Business number to your MIS group.  
It silently reads every message, extracts financial data, and feeds it to your tracker.

---

## STEP 1: Get a Phone Number (5 minutes)

Buy a new SIM card — ₹100 from any Airtel/Jio store.  
This number becomes your "MIS Bot" number.  
**Don't use an existing WhatsApp number** — it will be converted to Business API.

---

## STEP 2: Create Meta Business Account (15 minutes)

1. Go to **business.facebook.com**
2. Click "Create Account"
3. Enter: Business name (Fidato Group), your name, business email
4. Verify email
5. You now have a Meta Business Portfolio

---

## STEP 3: Set Up WhatsApp Business API (20 minutes)

1. Go to **developers.facebook.com**
2. Click "My Apps" → "Create App"
3. Select **"Business"** type → Next
4. App name: "Fidato MIS Bot" → Create
5. On the app dashboard, find **"WhatsApp"** → Click **"Set Up"**
6. It will ask you to select your Meta Business Portfolio (from Step 2)
7. You'll see a **test phone number** provided by Meta — this works for testing
8. To use your own number: Go to **WhatsApp → API Setup → Add phone number**
9. Enter the new SIM number → Verify via SMS OTP
10. Done — you now have API access

**Note down these three things from the dashboard:**
- Phone Number ID
- WhatsApp Business Account ID  
- Temporary Access Token (you'll make a permanent one later)

---

## STEP 4: Deploy the Server (15 minutes)

### Option A: Railway.app (easiest, free tier)

1. Go to **railway.app** → Sign up with GitHub
2. Click "New Project" → "Deploy from GitHub repo"
3. Upload the `whatsapp-mis-bot` folder to a GitHub repo first, or:
4. Click "New Project" → "Empty Project" → "Add Service" → "Empty Service"
5. In the service settings, paste the server.js code
6. Add environment variables:
   ```
   WHATSAPP_VERIFY_TOKEN = any-random-string-you-choose
   WHATSAPP_API_TOKEN = (from Meta dashboard)
   WHATSAPP_PHONE_ID = (from Meta dashboard)
   PORT = 3000
   ```
7. Railway gives you a URL like: `https://your-app.railway.app`

### Option B: Any VPS (DigitalOcean, AWS, etc.)

```bash
# On your server
git clone <your-repo>
cd whatsapp-mis-bot
npm install
# Set environment variables
export WHATSAPP_VERIFY_TOKEN="any-random-string"
export WHATSAPP_API_TOKEN="from-meta-dashboard"
export WHATSAPP_PHONE_ID="from-meta-dashboard"
# Start
npm start
```

Use **pm2** to keep it running:
```bash
npm install -g pm2
pm2 start server.js --name mis-bot
pm2 save
pm2 startup
```

---

## STEP 5: Connect Webhook to Meta (5 minutes)

1. Go back to **developers.facebook.com** → Your App → WhatsApp → Configuration
2. Under **Webhook**, click "Edit"
3. **Callback URL**: `https://your-domain.com/webhook`  
   (your Railway URL or VPS domain)
4. **Verify Token**: The same random string you set in WHATSAPP_VERIFY_TOKEN
5. Click "Verify and Save"
6. Under **Webhook Fields**, subscribe to: **messages**

---

## STEP 6: Add Bot Number to Group (2 minutes)

1. Open your MIS WhatsApp group
2. Add the new Business API number as a participant
3. That's it — it will now receive every message posted in the group

---

## STEP 7: Connect Google Sheets (Optional, 10 minutes)

This stores every parsed message in a Google Sheet for backup and analysis.

1. Go to **console.cloud.google.com**
2. Create a project → Enable "Google Sheets API"
3. Create a **Service Account** → Download the JSON key file
4. Create a Google Sheet with these column headers in Sheet1 (rename to "MIS_Feed"):
   ```
   Date | Sender | Type | Category | Raw Message | Amounts | Signals | Parsed Data | Timestamp | Alert
   ```
5. Share the sheet with the service account email (from the JSON file)
6. Put the JSON key file as `credentials.json` in the bot folder
7. Add the Sheet ID to your config (the long string in the sheet URL)

---

## STEP 8: Generate Permanent Token (5 minutes)

The test token from Meta expires in 24 hours. For permanent access:

1. In Meta Developer Dashboard → Your App → WhatsApp → API Setup
2. Click "Generate Permanent Token" or:
3. Go to Business Settings → System Users → Add System User
4. Give it "Admin" role
5. Add your WhatsApp app as an asset
6. Generate token with `whatsapp_business_messaging` permission
7. Replace the token in your server config

---

## How It Works After Setup

```
Someone posts in WhatsApp group
        ↓
Meta pushes message to your webhook
        ↓
Server parses: type, amounts, signals, category
        ↓
Stores in memory + Google Sheet
        ↓
Your tracker reads from /api/messages endpoint
```

---

## API Endpoints (for your tracker)

| Endpoint | What it returns |
|----------|----------------|
| `GET /api/messages` | All parsed messages (latest 50) |
| `GET /api/messages?type=daily_mis` | Only daily MIS messages |
| `GET /api/signals` | Risk and cost signals only |
| `GET /api/daily-summary?date=2026-03-03` | Summary for a specific date |
| `GET /health` | Server status |

---

## Message Types the Bot Detects

| Type | Trigger Keywords |
|------|-----------------|
| `daily_mis` | "collection", "expenditure", "closing balance" |
| `fund_position` | "fund position", "net usable", "bank balance" |
| `site_update` | "contractor", "outstanding", "steel", "rmc" |
| `sales_update` | "booking", "unsold", "inventory", "sold" |
| `promoter_draw` | "mm", "sm", "drawing", "directors" |
| `office_expense` | "office", "gk-1", "salary", "electricity" |
| `compliance` | "rera", "oc", "edc", "noc", "legal" |

---

## Cost Summary

| Item | Cost |
|------|------|
| New SIM | ₹100 (one-time) |
| Meta Cloud API | Free (1,000 conversations/month) |
| Railway hosting | Free tier (or ₹500/month for production) |
| Google Sheets | Free |
| **Total** | **₹100 to start, ₹500/month for production** |

---

## Troubleshooting

**Webhook not verifying?**  
→ Check that your server is publicly accessible and the verify token matches exactly.

**Messages not arriving?**  
→ Ensure you subscribed to "messages" in webhook fields.  
→ Check that the bot number is added to the group.

**Google Sheet not updating?**  
→ Check that the sheet is shared with the service account email.  
→ Check the sheet name is exactly "MIS_Feed".

**Token expired?**  
→ Generate a permanent token via System Users (Step 8).

---

## Next Steps

Once running, connect the `/api/messages` endpoint to your React tracker's  
WhatsApp tab. Replace the sample data with live API calls.

For image MIS (screenshots of Excel), you'd add OCR using Google Vision API  
or Anthropic's Claude API to extract text from the images — that's a Phase 2 enhancement.
